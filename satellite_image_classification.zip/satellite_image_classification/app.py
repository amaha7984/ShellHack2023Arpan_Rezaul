

from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression

from flask import Flask, request, jsonify, render_template
import numpy as np
import os
from PIL import Image
import io
import tensorflow as tf
from tensorflow.keras.preprocessing import image
from tensorflow.keras.applications.vgg16 import VGG16, preprocess_input, decode_predictions
from sklearn.metrics import accuracy_score

app = Flask(__name__)

# Initialize model
base_model = VGG16(weights='imagenet', include_top = False, input_shape = (224, 224, 3))
# root_dir = 'static/train'

clf = LogisticRegression()
# Function to train the logistic regression classifier
def train_classifier():
    global clf  # Use the global classifier
    train_features = []
    train_labels = []
    test_features = []
    test_labels = []
    
    for folder_name in os.listdir('static/train/'):
        if not folder_name.startswith('.'):
            for file_name in os.listdir(os.path.join('static/train/', folder_name)):
                #if file_name.endswith('.jpg') or file_name.endswith('.png'):
                if file_name.endswith(('.jpg', '.jpeg', '.png')):
                    img_path = os.path.join('static/train/', folder_name, file_name)
                    img = image.load_img(img_path, target_size=(224, 224))
                    x = image.img_to_array(img)
                    x = np.expand_dims(x, axis=0)
                    x = preprocess_input(x)

                    feature = base_model.predict(x)
                    flat_feature = feature.flatten()

                    train_features.append(flat_feature)
                    train_labels.append(folder_name)
    #load and preprocess test images                
    for folder_name in os.listdir('static/test/'):
        if not folder_name.startswith('.'):
            for file_name in os.listdir(os.path.join('static/test/', folder_name)):
                #if file_name.endswith('.jpg') or file_name.endswith('.png'):
                if file_name.endswith(('.jpg', '.jpeg', '.png')):
                    img_path = os.path.join('static/test/', folder_name, file_name)
                    img = image.load_img(img_path, target_size=(224, 224))
                    x = image.img_to_array(img)
                    x = np.expand_dims(x, axis=0)
                    x = preprocess_input(x)

                    feature = base_model.predict(x)
                    flat_feature = feature.flatten()

                    test_features.append(flat_feature)
                    test_labels.append(folder_name)

    train_features = np.array(train_features)
    train_labels = np.array(train_labels)
    test_features = np.array(test_features)
    test_labels = np.array(test_labels)

    # Fit all data, no need for a test set in this case
    clf.fit(train_features, train_labels)

    # Test the classifier
    y_pred = clf.predict(test_features)
    acc = accuracy_score(test_labels, y_pred)
    print(f'Accuracy on test set: {acc}')





train_classifier()



@app.route('/')
def main():
    return render_template('index.html')


@app.route('/classify', methods=['POST'])
def classify_image():
    if 'file' not in request.files:
        return jsonify({'error': 'no file'})
    uploaded_file = request.files['file']
    file_name = uploaded_file.filename

    lat, long = file_name.split('_')  # Split filename to get lat and long
    lat, long = lat.strip(), long.strip('.jpg').strip('.jpeg').strip('.png')  # Remove file extension from longitude
    
    file = uploaded_file.read()
    image = Image.open(io.BytesIO(file)).convert("RGB")
    image = image.resize((224, 224))

    x = np.array(image)
    x = np.expand_dims(x, axis=0)
    x = preprocess_input(x)

    print("Shape:", x.shape)  # Debugging information
    print("Min:", np.min(x))
    print("Max:", np.max(x))
    print("Mean:", np.mean(x))
    feature = base_model.predict(x)
    
    flat_feature = feature.flatten()
    flat_feature = flat_feature.reshape(1, -1)

    y_pred_single = clf.predict(flat_feature)

    return jsonify({'result': y_pred_single[0], 'Lat': lat, 'Long': long})


if __name__ == '__main__':
    app.run()
