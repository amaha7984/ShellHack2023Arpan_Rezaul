<?php
 
	include('../b4start.conf.php');

	include($_SERVER['DOCUMENT_ROOT'] . b4DIR.'/dbconn/dbconn.php');
	include($_SERVER['DOCUMENT_ROOT'] . b4DIR.'/dbconn/az.multi.upload.class.php');

	
	$ajaxUserID = $_REQUEST['ajaxUserID'];
	$ajaxBraID = $_REQUEST['ajaxBraID'];
	$chkValue = $_REQUEST['chkValue'];
	if($chkValue == 'showListValue'){
	
	// show product
	$sql2 = "SELECT * FROM  donation_tbl WHERE 1 order by donation_id asc";
	$result = selectCode($sql2);
	$totalOrder = selectCountRows($sql2);
	

		if($totalOrder > 0){
		?>
   <table class="table table-striped table-hover" id="datatable3" cellspacing="0" width="100%">
    <thead>
        <tr>
          <th style="width:15%">Donation Id / Date</th>
          <th style="width:15%">Donor Information</th>
          <th style="width:15%">Donate For</th>
          <th style="width:10%">Donate Amount</th>
          <th style="width:13%">PaymentStatus</th>
          
        </tr>
    </thead>
    <tbody>
    <?php 
		foreach($result as $k => $showOrderList){	
	?>
        <tr>
            <td>
            <b>ID:</b> <?php echo $showOrderList['online_donation_id']; ?><br>
            <b>Date:</b> <?php echo $showOrderList['donation_date']; ?><br>
            </td>
            <td>
            <b>Name:</b> <?php echo $showOrderList['first_name']." ".$showOrderList['last_name']; ?><br>
            <b>Cell:</b> <?php echo $showOrderList['cell_number']; ?><br> <b>Email:</b> <?php echo $showOrderList['contact_email']; ?><br>    
            </td>
            <td>
            <b>Donation For:</b><br>
            <?php   
            $sql2 = "SELECT * FROM  disaster_list_tbl WHERE dis_id = ".$showOrderList['payment_from'] ;
	        $result3 = selectCode($sql2);echo $result3[0]['dis_name']; 
            ?>
            </td>
            <td>$<?php echo $showOrderList['donation_amount']; ?></td>
            <td><?php 
			if($showOrderList['donation_status']=='1'){echo "<span style='color: #FF9900; font-weight:bold'>Payment Success</span>";}
			if($showOrderList['donation_status']=='2'){echo "<span style='color: #990000; font-weight:bold'>Payment Awaiting</span>";}
			
			?>
            </td>
            
        </tr>
    <?php } } ?>
    </tbody>
</table> 	
	<script>
	        $('#datatable3').dataTable({
            dom: '<"top dt-panelmenu"Bf>rt<"bottom dt-panelfooter"ip>',
            buttons: ['copy', 'excel', 'pdf', 'csv', 'print'],
            "displayLength": 20,
			"aoColumnDefs": [ { "bSortable": false, "aTargets": [  1,2,3,4   ] }]
        });

	</script>

<?php	
	
	}
	
	echo ($senddata);
 
?>