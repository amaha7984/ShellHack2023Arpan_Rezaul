<?php
 
 	include('../b4start.conf.php');

	include($_SERVER['DOCUMENT_ROOT'] . b4DIR.'/dbconn/dbconn.php');
	include($_SERVER['DOCUMENT_ROOT'] . b4DIR.'/dbconn/az.multi.upload.class.php');

	session_start();
	
	$ajaxCatID = $_REQUEST['ajaxCatID'];
	$chkValue = $_REQUEST['chkValue'];
		
	if($chkValue == 'showListValue'){
	
		$sql = "SELECT * FROM disaster_list_tbl WHERE 1 order by dis_id desc";
		$productListData = selectCode($sql);
	
		if($productListData){
			$j = 1;
			foreach($productListData as $k => $showProductList){
	
?>
    		
        <div class="col-md-4 col-sm-4 wow zoomIn" data-wow-delay="0.<?php echo $j++;?>s">
            <a class="strip_list grid" href="<?php echo b4DIR; ?>/php_files/contents/contents.php?cmd=donateNow&disID=<?php echo $showProductList['dis_id']; ?>">
                <div class="desc">
                    <div class="thumb_strip">
                        <?php if($showProductList['dis_image'] == ''){ ?>
                        <img src="<?php echo b4DIR; ?>/templates/common/image/images/defaultImage.jpg" alt="">
                         <?php }else{ ?>
                         <img src="<?php echo $showProductList['dis_image']; ?>" alt="<?php echo $showProductList['dis_image']; ?>">
                         <?php } ?>
                    </div>
                    
                    <h3 style="font-size:18px"><?php echo $showProductList['dis_name']; ?></h3>
                    <div class="type">
                        <?php
                        echo $showProductList['dis_city'];
						?>
                    </div>
                    <div class="location">
                        <center><span class="btn_full_outline" style="background-color: #fff; border-color: #e02b20; color:#000; width:50%; margin-top:10px">Donate Now</span></center>
                    </div>
                    
                </div>
            </a>
        </div>
    
    <?php
			}
		}
		
		} 
	
	?>

<?php	
	
	echo ($senddata);
 
?>