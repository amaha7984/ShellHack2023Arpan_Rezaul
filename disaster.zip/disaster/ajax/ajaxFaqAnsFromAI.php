<?php
	
	include('../b4start.conf.php');
    include($_SERVER['DOCUMENT_ROOT'] . b4DIR.'/dbconn/dbconn.php');

    $askedQuestion = $_REQUEST['askedQuestion'];
    $doActionAJ = $_REQUEST['doActionAJ'];

	if($doActionAJ == 'sendDataToAjax'){
		
		if($askedQuestion != ''){
			
			$sql1 = "select * from faq_tbl where faq_question like '".$askedQuestion."%'"; 
			$PpreDefinedAnswer = selectCode($sql1);
			$description = $PpreDefinedAnswer[0]['description'];

            if($description){
                echo $description;
            }else{
                $apiKey = "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";
                $model = "text-davinci-003";
                $prompt = $askedQuestion;
                //$prompt = "Is there any new research done with cancer cell in GAN?";
                $temperature = 0.7;
                $maxTokens = 256;
                $topP = 1;
                $frequencyPenalty = 0;
                $presencePenalty = 0;

                $data = array(
                    'model' => $model,
                    'prompt' => $prompt,
                    'temperature' => $temperature,
                    'max_tokens' => $maxTokens,
                    'top_p' => $topP,
                    'frequency_penalty' => $frequencyPenalty,
                    'presence_penalty' => $presencePenalty
                );

                $ch = curl_init();

                curl_setopt($ch, CURLOPT_URL, "https://api.openai.com/v1/completions");
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
                curl_setopt($ch, CURLOPT_POST, 1);
                curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
                curl_setopt($ch, CURLOPT_HTTPHEADER, array("Content-Type: application/json", "Authorization: Bearer " . $apiKey));

                $response = curl_exec($ch);
                $err = curl_error($curl);
                if($err) {
                    echo 'We are unable to process your request. Please try again.';
                } else {
                    $response = json_decode($response, true);
                    $statusGet = $response['choices']['0']['text'];
                    echo $statusGet;
                }
            }
		
		}
				
	}

 
?>