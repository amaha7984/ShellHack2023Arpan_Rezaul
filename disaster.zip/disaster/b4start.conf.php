<?php
   define('b4DIR',             '/disaster');
?>