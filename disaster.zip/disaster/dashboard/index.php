<?php
  include('../b4start.conf.php');
  header("Location: ".b4DIR."/php_files/standard/user_home/user_home.php?home=home_client_login");

?>