<?php

	define('E_NONE', 0);
	error_reporting(E_NONE);
		
	$phpVersion = phpversion();

	if($phpVersion >= 7){
		
		$dbconi = mysqli_connect('localhost', 'root', '', 'disaster') or die("Unable to Connect");
	
	}
	else{
		
		$dbcon = mysql_connect('localhost', 'root', '') or die("Could not connect: " . mysql_error());
    	mysql_select_db('disaster', $dbcon) or die("Could not find: " . mysql_error());
	
	}

/* start sqlScript */	

	function selectCode($sql)
	{
		global $dbconi;
		$phpVersion = phpversion();
		
		$data=array();
		
		if($phpVersion >= 7){
			$result = mysqli_query($dbconi, $sql);
			$data=array();
			if($result){
				if(mysqli_num_rows($result)>0){
					while($rs=mysqli_fetch_assoc($result)){
						$data[]=$rs;
					}
				}
			}
		}
		else{
			
			$result = mysql_query($sql);
			if($result){
				if(mysql_num_rows($result)>0){
					while($rs=mysql_fetch_assoc($result)){
						$data[]=$rs;
					}
				}
			}
		}
		
		return $data;
	
	}

	function selectCountRows($sql)
	{
	
		global $dbconi;
		$phpVersion = phpversion();
		
		if($phpVersion >= 7){
			$result = mysqli_query($dbconi, $sql);
			$data = mysqli_num_rows($result);
		}
		else{
			$result = mysql_query($sql);
			$data = mysql_num_rows($result);
		}
		
		return $data;
	
	}
	
	function insertCode($sql)
	{
	
		global $dbconi;
		$phpVersion = phpversion();
		
		if($phpVersion >= 7){
					
			$result = mysqli_query($dbconi, $sql);
			$insert_new_id = mysqli_insert_id($dbconi);
		}
		else{
			$result = mysql_query($sql);
			$insert_new_id = mysql_insert_id();
		}
		
		return $insert_new_id;
	
	}
	
	function updateCode($sql)
	{
	
		global $dbconi;
		$phpVersion = phpversion();
		
		if($phpVersion >= 7){
					
			$result = mysqli_query($dbconi, $sql);
		}
		else{
			$result = mysql_query($sql);
		}
		
		return $result;
	
	}
	
	function deleteCode($sql)
	{
	
		global $dbconi;
		$phpVersion = phpversion();
		
		if($phpVersion >= 7){
					
			$result = mysqli_query($dbconi, $sql);
		}
		else{
			$result = mysql_query($sql);
		}
		
		return $result;
	
	}
	
	/*Set Time Zone*/
		$sql = "select * from time_zone_tbl where time_zone_id = '2'";
		$timeZoneInfo = selectCode($sql);
		$time_zone_title = $timeZoneInfo[0]['time_zone_title'];
		$time_zone_php = $timeZoneInfo[0]['time_zone_php'];
		
		date_default_timezone_set('America/Chicago');

	/*Set Time Zone*/
	
	function todayDate()
	{
	
 		$result = date('Y-m-d h:i:s A');
		
		return $result;
	
	}



/* end sqlScript */

?>