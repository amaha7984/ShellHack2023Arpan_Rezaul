<?php

 $gmtMktime = mktime(gmdate("H"),gmdate("i"),gmdate("s"),gmdate("m"),gmdate("d"),gmdate("y"));
 
 echo date('Y-m-d h:i:s A'). " server time<br><br>".date(e)."<br><br>";
 date_default_timezone_set('America/Chicago');
 echo date('Y-m-d h:i:s A'). " USA CENTRAL Time<br><br>".date(e);
?>